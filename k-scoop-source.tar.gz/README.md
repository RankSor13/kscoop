# K-Scoop — Korean Showbiz News

> Daily Korean celebrity gossip, trending news, and upcoming K-drama releases — gathered fresh from the web every morning.

![K-Scoop](download/kscoop-final-top.png)

## Live Preview

The site is live in the sandbox preview panel. Click **Open in New Tab** above the preview to view it in a separate browser tab.

## What's Inside

- **18 curated news articles** spanning gossip, upcoming K-dramas, trending stories, and casting news — all linked to original sources (Soompi, BBC, SCMP, Forbes, TIME, SBS Star, Korea Times, Straits Times, Koreaboo, allkpop, and more).
- **8 trending actor & actress profiles** — Kim Soo-hyun, Suzy, IU, Byeon Woo-seok, Kim Seon-ho, Hong Yi-seol, Ju Ji-hoon, Park Bo-young.
- **12 upcoming 2026 K-dramas** with premiere dates, platforms (Netflix / Disney+ / tvN / SBS / ENA), genres, casts, and a hype meter.
- **Live refresh button** — pulls fresh headlines from the web on demand via z-ai SDK.
- **Bookmark drawer** — save articles locally, no login required.
- **Dark / light theme** toggle, fully responsive, mobile-first.

## Tech Stack

Next.js 16 · TypeScript · Tailwind CSS 4 · shadcn/ui · Framer Motion · next-themes · z-ai-web-dev-sdk

## Daily Updates

A GitHub Action (`.github/workflows/daily-refresh-and-deploy.yml`) runs daily at 08:00 UTC, fetches fresh news via z-ai web search, commits the refreshed `src/data/news.ts`, builds the static site, and deploys to GitHub Pages.

## Deploy

See [`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md) for the full GitHub Pages + Cloudflare DNS setup guide.

## Sources

All headlines link back to the original publisher. Aggregated sources: Soompi, Koreaboo, allkpop, SCMP, BBC, Forbes, TIME, SBS Star, The Korea Times, The Straits Times, MyDramaList, Wikipedia.

---

For fan aggregation only. All article content belongs to its original publishers. Code is MIT-licensed.
